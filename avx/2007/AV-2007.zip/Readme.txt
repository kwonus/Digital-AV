AV Bible -- Build 62.XA211 -- 11 February 2010
Version 2007
Copyright (c) 1996-2010  Kevin Wonus

Some graphics authored by David Antenne, used by permission

BEFORE YOU BEGIN:
================
If upgrading from a previous version of AV Bible (such as AV-2005):
        a)  Close all instances of Microsoft Word

If upgrading on Windows 2000, Windows 98, Window 95, or Windows Me,
also do the following (may not be required if running XP or Vista)

        b)  Close the AV-Bible server from the icon
            tray.  If you don't know how to do this,
            then just reboot and install AV-Bible
            immediately after rebooting.

1)	Execute the "AV Bible" Installation Program:
		setup.exe	(for CDROM or Diskette Edition)
		or
		AV-Bible.exe	(for Internet Edition)

2)	Execute "The Holy Bible" from the Windows
	"Start Menu"  (AV Bible-->The Holy Bible)

	On some versions of Windows, a publication
	phase of the bible text occurs.  This first
	execution takes 60-90 seconds as it publishes
	the entire KJV Bible in HTML format.

	Subsequent executions do not exhibit this delay.

3)	AV Bible seamlessly inter-operates with Microsoft
	Word 2007 Word XP, Word 2000, and Word 97.  If MS-Word
	is installed, then this feature is now installed by
	default.  If you would like to enable integrated
	support for Microsoft Word, then be sure that this
	option is selected during installation.  Enabling
	this feature facilitates the publishing of the
	the scripture with or without your own notations.

	About Windows Vista and Windows 7:
	Integration with older version of Microsft Word
	still always provide seemless integration with
	AV-Bible.  There are instances where AV-Bible
	integration with Word-2007 does not fully function
	on the newset versions of Microsoft Windows.
	The AV-2007 author has not fully analyzed this,
	but it appears to be limited to 64-bit installations.
	If you are running 64-bit Windows, you may want
	to check-out www.rtbible.com:  that software is
	expected to be compatible with 64-bit Windows.    

	About Older Versions:
	If you are still using Word-97 or Windows-98, then
	after installation, you may need to run the AV-Bible
	"Integration Assistant".  To do this, choose
	<Advanced Integration> on the <Options> tab.

	If you are still using Word-95, or Windows-95,
	then close the AV-Bible installation program (or
	uninstall AV-Bible) and locate the AV-2000 directory
	on this CD (or from http://www.avbible.net) and
	install AV-2000 instead.

4)	Send mailto:kevin@wonus.com if you have
	questions or check out these web sites:
	http://www.avbible.net
	http://www.rtbible.com
	http://www.avword.com

NOTE:
	In older versions of Windows, AV-Bible may require
	a newer version of Internet Explorer than the one
	that you currently have installed.  If you have
	Windows 95, Windows 98, or Windows NT, then check
	to see that you have Microsoft Internet Explorer
	version 4.01 or above.  Even though an Internet
	connection is not required, AV-Bible software uses
	Internet Explorer to render Bible text.

	(Microsoft Internet Explorer version 5.5 or higher
	 is recommended).

	Please follow Microsoft's instructions completely
	prior to installing AV-Bible.  AV-Bible will not
	install correctly without Internet Explorer.

See license-2007.txt to review the license agreement.